#include "framework/service_pipeline.hpp"

#include <cstdint>
#include <filesystem>
#include <optional>
#include <sstream>
#include <stdexcept>
#include <string>

#include <ecal/ecal.h>
#include <zmq_rpc/json/json.hpp>

using SERVICE_NAMESPACE_PREFIX::framework::ServicePipeline;
using str = typename ServicePipeline::str;

namespace
{
    using json = zmq_rpc::json::json;
    using gateway_t = pooyan::board::frz::Gateway;

    static str get_service_name(const str& service_name, const str& service_version)
    {
        std::ostringstream _;
        _ << service_name << " (" << service_version << ")";
        return _.str();
    }

    struct ConfigDdcRequest
    {
        std::string channel;
        std::int64_t freq{ 0 };
        std::int64_t sampling_rate{ 0 };
        int adc{ -1 };
        int channel_num{ -1 };
        int adc_prec{ -1 };
        bool with_fractional_resampler{ false };
        bool with_matched_filter{ false };
        bool with_symbol_output{ false };
        bool is_fixed{ false };
    };

    struct CaptureStartRequest
    {
        std::string channel;
        std::int64_t size{ 0 };
        std::int64_t freq{ 0 };
        std::int64_t fs{ 0 };
        int device_index{ -1 };
        int adc{ -1 };
        int channel_num{ -1 };
    };

    struct AttenuationRequest
    {
        int channel{ -1 };
        int attenuation{ 0 };
    };

    struct DmaRequest
    {
        // channel: "wb" or "nb"; channel_num: 0 for WB, 0..3 for NB; adc: 0 or 1.
        std::string channel;
        int channel_num{ 0 };
        int adc{ 0 };
        std::int64_t size{ 0 };
        std::int64_t offset{ 0 };
        int timeout_ms{ -1 };
    };

    static void from_json(const json& j, ConfigDdcRequest& value)
    {
        zmq_rpc::json::get_from_json_to(j, "channel", value.channel);
        zmq_rpc::json::get_from_json_to(j, "freq", value.freq);
        zmq_rpc::json::get_from_json_to(j, "sampling_rate", value.sampling_rate);
        zmq_rpc::json::get_from_json_to(j, "adc", value.adc);
        zmq_rpc::json::get_from_json_to(j, "channel_num", value.channel_num);
        zmq_rpc::json::get_from_json_to(j, "adc_prec", value.adc_prec);
        zmq_rpc::json::get_from_json_to(j, "with_fractional_resampler", value.with_fractional_resampler);
        zmq_rpc::json::get_from_json_to(j, "with_matched_filter", value.with_matched_filter);
        zmq_rpc::json::get_from_json_to(j, "with_symbol_output", value.with_symbol_output);
        zmq_rpc::json::get_from_json_to(j, "is_fixed", value.is_fixed);
    }

    static void from_json(const json& j, CaptureStartRequest& value)
    {
        zmq_rpc::json::get_from_json_to(j, "channel", value.channel);
        zmq_rpc::json::get_from_json_to(j, "size", value.size);
        zmq_rpc::json::get_from_json_to(j, "freq", value.freq);
        zmq_rpc::json::get_from_json_to(j, "fs", value.fs);
        zmq_rpc::json::get_from_json_to(j, "device_index", value.device_index);
        zmq_rpc::json::get_from_json_to(j, "adc", value.adc);
        zmq_rpc::json::get_from_json_to(j, "channel_num", value.channel_num);
    }

    static void from_json(const json& j, AttenuationRequest& value)
    {
        zmq_rpc::json::get_from_json_to(j, "channel", value.channel);
        zmq_rpc::json::get_from_json_to(j, "attenuation", value.attenuation);
    }

    static void from_json(const json& j, DmaRequest& value)
    {
        zmq_rpc::json::get_from_json_to(j, "channel", value.channel);
        zmq_rpc::json::get_from_json_to(j, "channel_num", value.channel_num);
        zmq_rpc::json::get_from_json_to(j, "adc", value.adc);
        zmq_rpc::json::get_from_json_to(j, "size", value.size);
        zmq_rpc::json::get_from_json_to(j, "offset", value.offset);
        zmq_rpc::json::get_from_json_to(j, "timeout_ms", value.timeout_ms);
    }

    static gateway_t::ConfigDDC::data_t make_config_ddc(const ConfigDdcRequest& request)
    {
        gateway_t::ConfigDDC::data_t data;
        data.channel = request.channel;
        data.freq = request.freq;
        data.sampling_rate = request.sampling_rate;
        data.adc = request.adc;
        data.channel_num = request.channel_num;
        data.adc_prec = request.adc_prec;
        data.with_fractional_resampler = request.with_fractional_resampler;
        data.with_matched_filter = request.with_matched_filter;
        data.with_symbol_output = request.with_symbol_output;
        data.is_fixed = request.is_fixed;
        return data;
    }

    static gateway_t::capture_apis_t::Start::data_t make_capture_start(const CaptureStartRequest& request)
    {
        gateway_t::capture_apis_t::Start::data_t data;
        data.channel = request.channel;
        data.size = request.size;
        data.freq = request.freq;
        data.fs = request.fs;
        data.device_index = request.device_index;
        data.adc = request.adc;
        data.channel_num = request.channel_num;
        return data;
    }

    template<typename T>
    static T call_dma(gateway_t& gateway, const DmaRequest& request)
    {
        if (request.size <= 0 || request.offset < 0)
            throw std::invalid_argument("DMA size must be positive and offset must not be negative");
        if (request.adc < 0 || request.adc > 1)
            throw std::invalid_argument("DMA adc must be 0 or 1");

        if (request.channel == "wb") {
            if (request.channel_num != 0)
                throw std::invalid_argument("WB channel_num must be 0");
            return request.adc == 0
                ? gateway.dma_wb_0_0(request.size, request.offset, request.timeout_ms)
                : gateway.dma_wb_1_0(request.size, request.offset, request.timeout_ms);
        }

        if (request.channel == "nb") {
            switch (request.channel_num) {
            case 0: return request.adc == 0 ? gateway.dma_nb_0_0(request.size, request.offset, request.timeout_ms) : gateway.dma_nb_1_0(request.size, request.offset, request.timeout_ms);
            case 1: return request.adc == 0 ? gateway.dma_nb_0_1(request.size, request.offset, request.timeout_ms) : gateway.dma_nb_1_1(request.size, request.offset, request.timeout_ms);
            case 2: return request.adc == 0 ? gateway.dma_nb_0_2(request.size, request.offset, request.timeout_ms) : gateway.dma_nb_1_2(request.size, request.offset, request.timeout_ms);
            case 3: return request.adc == 0 ? gateway.dma_nb_0_3(request.size, request.offset, request.timeout_ms) : gateway.dma_nb_1_3(request.size, request.offset, request.timeout_ms);
            default: throw std::invalid_argument("NB channel_num must be between 0 and 3");
            }
        }

        throw std::invalid_argument("DMA channel must be 'wb' or 'nb'");
    }
}

// The BoardZmqClient response models provide from_json() for receiving board
// responses. These to_json() overloads allow the same models to be returned by
// this service's RPC endpoints without introducing duplicate response DTOs.
namespace nooyan::zmq_client::api::board::adc::channel::user
{
    static void to_json(nlohmann::json& j, const Post::Result& r)
    {
        j = nlohmann::json{
            {"channel", r.channel}, {"adc_freq", r.adc_freq}, {"channel_fs", r.channel_fs},
            {"freq", r.freq}, {"fs", r.fs}, {"nco", r.nco}, {"user_freq", r.user_freq},
            {"adc", r.adc}, {"adc_prec", r.adc_prec}, {"channel_num", r.channel_num},
            {"cic_decimation", r.cic_decimation}, {"cic_prec", r.cic_prec}, {"mgc_gain", r.mgc_gain},
            {"mode", r.mode}, {"mxr_prec", r.mxr_prec}, {"resampler_mu", r.resampler_mu},
            {"wb_chain", r.wb_chain}, {"wb_cic_prec", r.wb_cic_prec}, {"wb_cic_rate", r.wb_cic_rate},
            {"agc_enable", r.agc_enable}, {"with_fractional_resampler", r.with_fractional_resampler},
            {"with_matched_filter", r.with_matched_filter}, {"with_symbol_output", r.with_symbol_output}
        };
    }
}

namespace nooyan::zmq_client::api::board::channel::adc
{
    static void to_json(nlohmann::json& j, const Post::Result& r)
    {
        j = nlohmann::json{{"channel", r.channel}, {"adc", r.adc}};
    }
}

namespace nooyan::zmq_client::api::board::attenuation
{
    static void to_json(nlohmann::json& j, const Post::Result& r)
    {
        j = nlohmann::json{{"channel", r.channel}, {"attenuation", r.attenuation}};
    }
}

namespace nooyan::zmq_client::api::capture::start
{
    static void to_json(nlohmann::json& j, const Post::Result& r)
    {
        j = nlohmann::json{
            {"capture_id", r.capture_id}, {"adc", r.adc}, {"is_wb", r.is_wb},
            {"channel_num", r.channel_num}, {"size", r.size}, {"freq", r.freq},
            {"fs", r.fs}, {"filename", r.filename}, {"block_size", r.block_size}
        };
    }
}

namespace nooyan::zmq_client::api::capture::status
{
    static void to_json(nlohmann::json& j, const Get::Result& r)
    {
        j = nlohmann::json{
            {"id", r.id}, {"adc", r.adc}, {"is_wb", r.is_wb}, {"channel_num", r.channel_num},
            {"size", r.size}, {"freq", r.freq}, {"fs", r.fs}, {"filename", r.filename},
            {"block_size", r.block_size}, {"error", r.error}, {"captured_size", r.captured_size},
            {"drop_size", r.drop_size}, {"dma_capacity", r.dma_capacity}, {"dma_size", r.dma_size},
            {"rate", r.rate}, {"progress", r.progress}, {"is_run", r.is_run}
        };
    }
}

namespace nooyan::zmq_client::api::capture::device::info
{
    static void to_json(nlohmann::json& j, const Get::Info& r)
    {
        j = nlohmann::json{
            {"name", r.name}, {"addr", r.addr}, {"index", r.index},
            {"total_space", r.total_space}, {"free_space", r.free_space}, {"block_size", r.block_size}
        };
    }
}

namespace nooyan::zmq_client::api::spectrum
{
    static void to_json(nlohmann::json& j, const Get::Result& r)
    {
        j = nlohmann::json{{"data", r.data}, {"start", r.start}, {"step", r.step}};
    }
}

ServicePipeline& ServicePipeline::load_config(const std::vector<std::string_view>& args)
{
    _tools.config.load_from_args(args);
    return *this;
}

ServicePipeline& ServicePipeline::initialize(const str& version)
{
    eCAL::Initialize(get_service_name(_tools.config().service_name(), version));
    _tools.zmq_context = std::make_shared<zmq::context_t>(1);
    return *this;
}

ServicePipeline& ServicePipeline::initial_board_gw()
{
    auto gateway = std::make_shared<tools_t::board_gateway_t>();
    gateway->initial(std::filesystem::path(_tools.config().board_config_path()));
    _tools.board_gateway = std::move(gateway);
    return *this;
}

ServicePipeline& ServicePipeline::initial_zmq_rpc()
{
    tools_t::zmq_rpc_server_t(_tools.zmq_rpc_tools)
        .initial(*_tools.zmq_context, _tools.config().rpc_endpoint());

    tools_t::zmq_rpc_server_t(_tools.zmq_rpc_tools)
        .initial_thread(100)
        .register_api("/api/board/config_ddc", "POST",
            [this](const ConfigDdcRequest& request) {
                return _tools.board_gateway->config_ddc(make_config_ddc(request));
            })
        .register_api("/api/board/adc/0", "POST",
            [this](int adc) { return _tools.board_gateway->set_adc_of_channel_0(adc); })
        .register_api("/api/board/adc/1", "POST",
            [this](int adc) { return _tools.board_gateway->set_adc_of_channel_1(adc); })
        .register_api("/api/board/attenuation", "POST",
            [this](const AttenuationRequest& request) {
                return _tools.board_gateway->set_channel_attenuation(request.channel, request.attenuation);
            })
        .register_api("/api/capture/start", "POST",
            [this](const CaptureStartRequest& request) {
                return _tools.board_gateway->start_capture(make_capture_start(request));
            })
        .register_api("/api/capture/stop", "POST",
            [this]() { return _tools.board_gateway->stop_capture(); })
        .register_api("/api/capture/status", "GET",
            [this]() { return _tools.board_gateway->capture_status(); })
        .register_api("/api/capture/device_info", "GET",
            [this]() { return _tools.board_gateway->capture_device_info(); })
        .register_api("/api/spectrum", "GET",
            [this](int channel) {
                if (channel != 0 && channel != 2)
                    throw std::out_of_range("spectrum channel must be 0 or 2");
                return _tools.board_gateway->spectrum(channel);
            })
        .register_api("/api/dma/data", "POST",
            [this](const DmaRequest& request) {
                return call_dma<gateway_t::DmaData::response_t>(*_tools.board_gateway, request);
            });

    return *this;
}

int ServicePipeline::finalize()
{
    eCAL::Process::SetState(
        eCAL::Process::eSeverity::healthy,
        eCAL::Process::eSeverityLevel::level1,
        "Run"
    );

    tools_t::zmq_rpc_server_t(_tools.zmq_rpc_tools).start();

    while (eCAL::Ok()) {
        if (_tools.reset_flag.load()) {
            eCAL::Finalize();
            return -1;
        }
        eCAL::Process::SleepMS(1000);
    }

    return eCAL::Finalize();
}
